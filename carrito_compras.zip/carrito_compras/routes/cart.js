module.exports = (db) => {
    const router = require('express').Router();

    // Agregar al carrito - MEJORADO
    router.post('/add', async (req, res) => {
        console.log('Solicitud agregar al carrito:', req.body);
        
        if (!req.session.user) {
            return res.json({ success: false, message: 'Debe iniciar sesión' });
        }

        const { productId, quantity = 1 } = req.body;
        const userId = req.session.user.id;

        // Validaciones
        if (!productId) {
            return res.json({ success: false, message: 'ID de producto no válido' });
        }

        try {
            // Verificar si el producto existe
            const [productResults] = await db.promise().query(
                'SELECT * FROM products WHERE id = ?',
                [productId]
            );

            if (productResults.length === 0) {
                return res.json({ success: false, message: 'Producto no encontrado' });
            }

            const product = productResults[0];

            // Verificar stock
            if (product.stock <= 0) {
                return res.json({ success: false, message: 'Producto sin stock' });
            }

            // Verificar si el producto ya está en el carrito
            const [existing] = await db.promise().query(
                'SELECT * FROM cart WHERE user_id = ? AND product_id = ?',
                [userId, productId]
            );

            if (existing.length > 0) {
                // Verificar que no exceda el stock
                const newQuantity = existing[0].quantity + parseInt(quantity);
                if (newQuantity > product.stock) {
                    return res.json({ 
                        success: false, 
                        message: `No hay suficiente stock. Máximo disponible: ${product.stock}` 
                    });
                }

                // Actualizar cantidad
                await db.promise().query(
                    'UPDATE cart SET quantity = ? WHERE user_id = ? AND product_id = ?',
                    [newQuantity, userId, productId]
                );
            } else {
                // Agregar nuevo producto
                await db.promise().query(
                    'INSERT INTO cart (user_id, product_id, quantity) VALUES (?, ?, ?)',
                    [userId, productId, quantity]
                );
            }

            // Obtener nuevo contador
            const [countResult] = await db.promise().query(
                'SELECT SUM(quantity) as total FROM cart WHERE user_id = ?',
                [userId]
            );

            const cartCount = countResult[0].total || 0;

            res.json({ 
                success: true, 
                message: 'Producto agregado al carrito',
                cartCount: cartCount
            });

        } catch (error) {
            console.error('Error completo agregando al carrito:', error);
            res.json({ 
                success: false, 
                message: 'Error del servidor al agregar producto' 
            });
        }
    });

    // Endpoint para obtener contador del carrito
    router.get('/count', async (req, res) => {
        if (!req.session.user) {
            return res.json({ count: 0 });
        }

        try {
            const [results] = await db.promise().query(
                'SELECT SUM(quantity) as total FROM cart WHERE user_id = ?',
                [req.session.user.id]
            );
            res.json({ count: results[0].total || 0 });
        } catch (error) {
            console.error('Error obteniendo contador:', error);
            res.json({ count: 0 });
        }
    });

    // Actualizar cantidad
    router.put('/update', async (req, res) => {
        if (!req.session.user) {
            return res.json({ success: false, message: 'Debe iniciar sesión' });
        }

        const { productId, quantity } = req.body;
        const userId = req.session.user.id;

        try {
            if (quantity <= 0) {
                // Eliminar producto si cantidad es 0
                await db.promise().query(
                    'DELETE FROM cart WHERE user_id = ? AND product_id = ?',
                    [userId, productId]
                );
            } else {
                // Actualizar cantidad
                await db.promise().query(
                    'UPDATE cart SET quantity = ? WHERE user_id = ? AND product_id = ?',
                    [quantity, userId, productId]
                );
            }

            res.json({ success: true, message: 'Carrito actualizado' });
        } catch (error) {
            console.error('Error actualizando carrito:', error);
            res.json({ success: false, message: 'Error al actualizar carrito' });
        }
    });

    // Eliminar producto del carrito
    router.delete('/remove', async (req, res) => {
        if (!req.session.user) {
            return res.json({ success: false, message: 'Debe iniciar sesión' });
        }

        const { productId } = req.body;
        const userId = req.session.user.id;

        try {
            await db.promise().query(
                'DELETE FROM cart WHERE user_id = ? AND product_id = ?',
                [userId, productId]
            );
            res.json({ success: true, message: 'Producto eliminado del carrito' });
        } catch (error) {
            console.error('Error eliminando del carrito:', error);
            res.json({ success: false, message: 'Error al eliminar producto' });
        }
    });

    // Vaciar carrito
    router.delete('/clear', async (req, res) => {
        if (!req.session.user) {
            return res.json({ success: false, message: 'Debe iniciar sesión' });
        }

        const userId = req.session.user.id;

        try {
            await db.promise().query(
                'DELETE FROM cart WHERE user_id = ?',
                [userId]
            );
            res.json({ success: true, message: 'Carrito vaciado' });
        } catch (error) {
            console.error('Error vaciando carrito:', error);
            res.json({ success: false, message: 'Error al vaciar carrito' });
        }
    });

    return router;
};